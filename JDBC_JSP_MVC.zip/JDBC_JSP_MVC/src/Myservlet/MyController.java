package Myservlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Users;
import util.DBUtil;

/**
 * Servlet implementation class MyController
 */
@WebServlet("/MyController")
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Object userList;
      
    public MyController() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		request.setCharacterEncoding("utf-8");
		//��ȡǰ�˵�������
		String requestCode = request.getParameter("requestCode");
		int code = Integer.valueOf(requestCode);
		int flag = -1;
        switch(code)
		{
        
		case 1:
			response.setContentType("text/html; charset=utf-8");
			response.setCharacterEncoding("utf-8");
			flag = -1;
			String uname = request.getParameter("username");
			String nname = request.getParameter("name");
//			int aage = Integer.parseInt(request.getParameter("age"));
			String aage = request.getParameter("age");
			String tele = request.getParameter("teleno");

			String sql = "insert into person values('" + uname + "','" + nname+ "','" + aage +"','"+ tele + "')";
			
			try {
				flag = DBUtil.insertUpdateDelete(sql);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			response.setContentType("text/html; charset=utf-8");
			response.setCharacterEncoding("utf-8");

			if(flag==1)   
			{
				response.getWriter().write("���ݿ�������:   " + "�ɹ�����person  " + uname);				
			}
			else
			{
				//response.getWriter().write("���ݿ�������:   " + "����ʧ��");
				response.getWriter().write("���ݿ�������:   " + "�ɹ�����person  " + uname);	
				String Default = "insert into users values('" + uname + "','888888')";
				
				try {
					DBUtil.insertUpdateDelete(Default);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					flag = DBUtil.insertUpdateDelete(sql);
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
				
			}
			
			response.getWriter().write("<br>"+"<a href='/JDBC_JSP_MVC/Queryallservlet'>�鿴���ݿ�����</a>");
			break;
		case 2:
			flag = -1;
			int flag2 = -1;
			response.setContentType("text/html; charset=utf-8");
			response.setCharacterEncoding("utf-8");
			
			String uname2 = request.getParameter("username");
			String sql2 = "delete from users where username = " + "'"+uname2+ "'";
			String sql_query = "select * from users where username = '" + uname2 + "'"; 
			 flag2 = DBUtil.select(sql_query, flag2);
			if(flag2 == -2)
			{
				response.getWriter().write("���ݿ�������:  ���û�������");
			}
			else
			{
			try {
				flag = DBUtil.insertUpdateDelete(sql2);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//response.getWriter().write(flag+"");
			
			if(flag==1)
			{
				response.getWriter().write("���ݿ�������:   " + "�ɹ���users����ɾ��  " + uname2);				
			}
			/*else if(flag == 0)
			{
				//response.getWriter().write("���ݿ�������:   " + "ɾ��ʧ��");
			   response.getWriter().write("���ݿ�������:  ���û�������");
			}*/
			else
			{
				//response.getWriter().write("���ݿ�������:   " + "ɾ��ʧ��");
			   response.getWriter().write("���ݿ�������:   " + "�ɹ���users����ɾ��  " + uname2);
               String Default2 = "delete from person where username = " + "'"+uname2+ "'";
				
				try {
					DBUtil.insertUpdateDelete(Default2);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					flag = DBUtil.insertUpdateDelete(sql2);
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
			}
			}
			response.getWriter().write("<br>"+"<a href='/JDBC_JSP_MVC/Queryallservlet'>�鿴���ݿ�����</a>");
			break;
		}
	}

}
