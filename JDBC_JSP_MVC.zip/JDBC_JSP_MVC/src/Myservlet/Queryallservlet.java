package Myservlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Person;
import entity.Users;
import util.DBUtil;


@WebServlet("/Queryallservlet")
public class Queryallservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Queryallservlet() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String sql1 = "select * from users";
		List<Object> usersList = DBUtil.select(sql1, Users.class,
				null);
		String sql2 = "select * from person";
		List<Object> personList = DBUtil.select(sql2, Person.class,
				null);
		request.setAttribute("usersList", usersList);
		request.setAttribute("personList", personList);
		request.getRequestDispatcher("DB_operate_result.jsp").forward(request, response);
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
