package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.mysql.jdbc.PreparedStatement;
 
 //公共数据库操作类
public class DBUtil {
	// 数据库连接地址
	public static String URL;
	// 用户名
	public static String USERNAME;
	// 密码
	public static String PASSWORD;
	// mysql的驱动类
	public static String DRIVER;

	private static ResourceBundle rb = ResourceBundle.getBundle("util.db-config");
	private DBUtil() {
	}
	
	// 使用静态块加载驱动程序
		static {
			URL = rb.getString("jdbc.url");
			USERNAME = rb.getString("jdbc.username");
			PASSWORD = rb.getString("jdbc.password");
			DRIVER = rb.getString("jdbc.driver");
			try {
				Class.forName(DRIVER);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		// 定义一个获取数据库连接的方法
		public static Connection getConn() {
			Connection conn = null;
			try {
				conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("获取连接失败");
			}
			return conn;
		}

//	关闭数据库连接

	/*	public static void close(ResultSet rs, Connection conn,
				PreparedStatement ps) {
			if (rs != null) {
	            try {
	                rs.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }

	        if (ps != null) {
	            try {
	                ps.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }

	        if (conn != null) {
	            try {
	                conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
		}*/
		public static void close(Connection connection,
				PreparedStatement preparedStatement) {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
 
//插入、删除、修改
//有缺省
//	public static boolean insertUpdateDelete(String sql, Object[] params)throws SQLException  {
//		Connection connection = getConn();
//		PreparedStatement preparedStatement = null;
//		int resultCode = -1;
//		try {
//			preparedStatement = (PreparedStatement) connection
//					.prepareStatement(sql);
//			for (int i = 1; i < params.length + 1; i++) {
//				// 赋值的时候，索引是从1开始的
//				preparedStatement.setObject(i, params[i - 1]);
//			}
//			resultCode = preparedStatement.executeUpdate();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			// 关闭连接
//			close(connection, preparedStatement);
//		}
//		return resultCode == 1 ? true : false;
//	}
	/*增删改:0-失败 1-成功  -1-系统错误*/
	public static int insertUpdateDelete(String sql)throws SQLException, ClassNotFoundException{
		Connection connection = getConn();
		
		PreparedStatement preparedStatement = null;
		//ResultSet rs = null;
		int resultCode = -1;
//		使用PreparedStatement:是Statement的子接口,可以传入带占位符的SQL语句，提供了补充占位符变量的方法
		// resultCode执行sql返回的结果值
		try
		{
			preparedStatement = (PreparedStatement) connection
					.prepareStatement(sql);
			//rs = preparedStatement.getGeneratedKeys();
			resultCode = preparedStatement.executeUpdate();
		if(resultCode>0){
                //System.out.println("操作成功，受到影响的行数为："+resultCode);
			return 1;    
        }
		else{
                //System.out.println("操作失败");
			return 0;
        }
		} catch(SQLException e){
			return -1;
			
		}catch(Exception e)
		{
			return -1;
		}finally {
			
			close(connection, preparedStatement);
		}
		//return resultCode == 1 ? true : false;
	}
	
 
//查询所有或者根据条件查询

	public static List<Object> select(String sql, Class classname,
			Object[] params) {
		// 获取数据库连接
		Connection connection = getConn();
		// 查询结果集
		List<Object> objectList = new ArrayList<Object>();
		try {
			
			PreparedStatement preparedStatement = (PreparedStatement) connection
					.prepareStatement(sql);
			// 如果有查询条件
			if (params != null) {
				for (int i = 1; i < params.length + 1; i++) {
					preparedStatement.setObject(i, params[i - 1]);
				}
			}

			ResultSet resultSet = preparedStatement.executeQuery();
			// 要查的列表数量
			int columnCount = resultSet.getMetaData().getColumnCount();
			while (resultSet.next()) {
				// 构建一个对象实例
				GenericClassBean<GenericClassBean> classBean = new GenericClassBean<GenericClassBean>(classname);
				Object beanObject = classBean.getClassBean(classBean);
 
				for (int i = 1; i <= columnCount; i++) {
					// 获取查询的字段名称
					String columnName = resultSet.getMetaData().getColumnName(i);
					// 获取查询的字段的值
					String value = resultSet.getString(i);
					// 给对象属性赋值
					GenericClassBean.setClassBeanPropertyValue(beanObject, columnName,
							value);
				}
				objectList.add(beanObject);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
 
		return objectList;
	}

	public static int select(String sql, int flag) {
		// TODO Auto-generated method stub
		Connection connection = getConn();
		
		try {
			
			PreparedStatement preparedStatement = (PreparedStatement) connection
					.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				flag = 1;//不为空
			}
			else
			{
				flag = -2;//为空
			}
			// 要查的列表数量
			int columnCount = resultSet.getMetaData().getColumnCount();
			
			
			String[] colNames = new String[columnCount];
			for(int i=0; i<columnCount; i++)
			{
				colNames[i] = resultSet.getMetaData().getColumnName(i+1);
				System.out.print(colNames[i] +"\t" );
			}
			System.out.print("\n");
			while(resultSet.next())
			{
				for(String colName:colNames){
					if(resultSet.getString(colName)==null)
					{
						System.out.print(" ");
					}
					else
					System.out.print(resultSet.getString(colName) + "\t");
				}
				System.out.println();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}


}

