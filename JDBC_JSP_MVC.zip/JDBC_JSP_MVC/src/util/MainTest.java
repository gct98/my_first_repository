package util;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import entity.Person;

public class MainTest {
	
	private static final boolean False = false;

	public static void menu()
	{
		System.out.println("\t������Ҫ���еĲ�����\n");
		System.out.println("\t1:�������"+"\t2:ɾ������"+"\t3:�޸Ĳ���"+"\t4:��ѯ����"+"\t5:��ӡ��"+"\t\t6:�˳�\n" );
	}
//	public static void print_table(String table)
//	{
//		String operate = "select * from " + table;
//		DBUtil.select(operate);
//	}
	
	public static String get_first_object(String str)//��ȡsql����е�key
	{
		Pattern p1=Pattern.compile("\'(.*?)\'");
		 Matcher m = p1.matcher(str);
		ArrayList<String> list = new ArrayList<String>();
		while (m.find()) {
		list.add(m.group().trim().replace("\'","")+" ");
      }
		String object = list.get(0);
		return object;
	}
	


	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		
		
//		String selectSql_3 = "select * from person";
//		List<Object> productList = DBUtil.select(selectSql_3, Person.class,
//				null);
//		System.out.print(productList.size());
		
//		for (int i = 0; i < productList.size(); i++) {
//			Person pro = (Person) productList.get(i);
//		System.out.println("name"+pro.getName());
//			
//		}
		String uname2 = "lyy";
		String sql_query = "select * from users";
		int flag = -1;
		flag = DBUtil.select(sql_query, flag);
		
		System.out.print(flag);
		
		
   
		/*String uname = "";
		String Default = "delete from person where username = " + "'"+uname+ "'";
		int f = DBUtil.insertUpdateDelete(Default);
		System.out.println(f);*/
//		String uname2 = "ly";
//		String sql_query = "select * from users"; 
//		List<Object> productList = DBUtil.select(sql_query , Person.class,
//			null);
//		System.out.print(productList.size());

		
		}
}
	


